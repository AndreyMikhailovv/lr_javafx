package sample;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

public class Controller {
    private ObservableList<outputInTab> fillingEl = FXCollections.observableArrayList();

    @FXML
    private TableView<outputInTab> tablev;

    @FXML
    private TableColumn<outputInTab, String> wordCol;

    @FXML
    private TextArea txtTA;

    @FXML
    private TextField addRowPole;

    @FXML
    void onClick_AddRow(ActionEvent event) {
        if (!addRowPole.getText().equals("")) {
            fillingEl.add(new outputInTab(addRowPole.getText()));
            wordCol.setCellValueFactory(new PropertyValueFactory<>("col1"));
            tablev.setItems(fillingEl);
        }
    }

    @FXML
    void onClick_AdjustText(ActionEvent event) {
        if (tablev.getSelectionModel().getSelectedItem() != null && !txtTA.getText().equals("")) {
            TablePosition pos = tablev.getSelectionModel().getSelectedCells().get(0);
            int row = pos.getRow();
            String selectedItem = (String) pos.getTableColumn().getCellObservableValue(tablev.getItems().get(row)).getValue();

            String newTxt = txtTA.getText().replaceAll("\\$",selectedItem);
            txtTA.setText(newTxt);
        }
    }

    @FXML
    void onClick_Clear(ActionEvent event) {
        tablev.getItems().clear();
    }
}