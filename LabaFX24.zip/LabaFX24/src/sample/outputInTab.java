package sample;

public class outputInTab {
    private String wordCol;

    public outputInTab(String wordCol) {
        this.wordCol = wordCol;
    }

    public outputInTab() {
    }
    public String getCol1() {
        return wordCol;
    }
    public void setCol1(String wordCol) {
        this.wordCol = wordCol;
    }
}