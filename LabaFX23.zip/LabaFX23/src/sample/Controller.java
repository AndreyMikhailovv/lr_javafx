package sample;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import java.util.Random;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.TableColumn;
import javafx.scene.control.cell.PropertyValueFactory;

public class Controller {
    double[] mass = new double[9];
    private ObservableList<outputInTab> fillingEl = FXCollections.observableArrayList();

    @FXML
    private TableView<outputInTab> tablev;
    @FXML
    private TableColumn<outputInTab, Double> kColumn;
    @FXML
    private TableColumn<outputInTab, Double> yColumn;

    @FXML
    private Label errorMess;

    @FXML
    private TextField aTF;

    @FXML
    private TextField bTF;

    @FXML
    void onClick_Clear(ActionEvent event) {
        aTF.clear();
        bTF.clear();
        tablev.getItems().clear();
    }

    @FXML
    void onClick_Exit(ActionEvent event) {
        System.exit(0);
    }

    @FXML
    void onClick_RandBut(ActionEvent event) {
        tablev.getItems().clear();
        Random rnd = new Random();
        for (int i=0; i<9; i++) {
            mass[i] = rnd.nextInt(101);
            fillingEl.add(new outputInTab(mass[i],"-"));
            kColumn.setCellValueFactory(new PropertyValueFactory<>("col1"));
            yColumn.setCellValueFactory(new PropertyValueFactory<>("col2"));
        }
        tablev.setItems(fillingEl);
    }

    @FXML
    void onClick_Run(ActionEvent event) {
        try {
            double a = Double.parseDouble(aTF.getText()) + 2;
            a = Double.parseDouble(bTF.getText()) + 2;
            errorMess.setVisible(false);
        }
        catch (Exception e) {
            errorMess.setVisible(true);
        }
        if (tablev.getItems() != null && !errorMess.isVisible()) {
            fillingEl.clear();
            fillingEl.add(new outputInTab(mass[0],"-"));
            kColumn.setCellValueFactory(new PropertyValueFactory<>("col1"));
            yColumn.setCellValueFactory(new PropertyValueFactory<>("col2"));
            double yEl;
            double a = Double.parseDouble(aTF.getText()) + 2;
            double b = Double.parseDouble(bTF.getText()) + 2;
            for (int i=0; i<8; i++) {
                double sigmaEl = 0;
                for (int j=i; j<8; j++) sigmaEl += mass[j];
                yEl = Math.sqrt(Math.pow(Math.cos(mass[i+1]),2)/((a*a+b*b)-Math.sin(mass[i+1])))*sigmaEl;
                fillingEl.add(new outputInTab(mass[i+1],String.valueOf(yEl)));
                kColumn.setCellValueFactory(new PropertyValueFactory<>("col1"));
                yColumn.setCellValueFactory(new PropertyValueFactory<>("col2"));
            }
            tablev.setItems(fillingEl);
        }
    }
}