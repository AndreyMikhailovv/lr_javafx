package sample;

import javafx.fxml.FXML;
import javafx.event.ActionEvent;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class Controller {

    @FXML
    private TextField xTF;

    @FXML
    private TextField aTF;

    @FXML
    private TextField bTF;

    @FXML
    private TextField answerTF;

    @FXML
    private Label errorLab;

    @FXML
    void onClick_clear(ActionEvent event) {
        aTF.clear();
        bTF.clear();
        xTF.clear();
        answerTF.clear();
    }

    @FXML
    void onClick_exit(ActionEvent event) {
        System.exit(0);
    }

    @FXML
    void onClick_run(ActionEvent event) {
        double y, x, a, b;
        x = Double.parseDouble(xTF.getText());
        a = Double.parseDouble(aTF.getText());
        b = Double.parseDouble(bTF.getText());
        if (x <= 7) {
            if (a != 0 || b != 0) {
                errorLab.setVisible(false);
                y = (x + 4) / (a * a + b * b);
                answerTF.setText(String.valueOf(y));

            }
            else errorLab.setVisible(true);
        }
        else if(x>7) {
            errorLab.setVisible(false);
            y = x * Math.pow((a + b),2);
            answerTF.setText(String.valueOf(y));
        }
    }
}