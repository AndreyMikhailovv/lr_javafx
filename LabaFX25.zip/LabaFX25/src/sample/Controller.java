package sample;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import java.util.Random;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.TableColumn;
import javafx.scene.control.cell.PropertyValueFactory;

public class Controller {
    double[] mass = new double[9];
    private ObservableList<outputInTab> fillingEl = FXCollections.observableArrayList();

    @FXML
    private TableView<outputInTab> tablev;
    @FXML
    private TableColumn<outputInTab, Double> kColumn;
    @FXML
    private TableColumn<outputInTab, Double> yColumn;

    @FXML
    private Label errorMess;

    @FXML
    private TextField aTF;

    @FXML
    private TextField bTF;

    @FXML
    void onClick_Clear(ActionEvent event) {
        aTF.clear();
        bTF.clear();
        tablev.getItems().clear();
    }

    @FXML
    void onClick_Exit(ActionEvent event) {
        System.exit(0);
    }

    @FXML
    void onClick_RandBut(ActionEvent event) {
        tablev.getItems().clear();
        Random rnd = new Random();
        for (int i=0; i<9; i++) {
            mass[i] = rnd.nextInt(101);
            fillingEl.add(new outputInTab(mass[i],"-"));
            kColumn.setCellValueFactory(new PropertyValueFactory<>("col1"));
            yColumn.setCellValueFactory(new PropertyValueFactory<>("col2"));
        }
        tablev.setItems(fillingEl);
    }

    @FXML
    void onClick_Run(ActionEvent event) {
        try {
            double a = Double.parseDouble(aTF.getText()) + 2;
            a = Double.parseDouble(bTF.getText()) + 2;
            errorMess.setVisible(false);
        }
        catch (Exception e) {
            errorMess.setVisible(true);
        }
        if (tablev.getItems() != null && !errorMess.isVisible()) {
            fillingEl.clear();
            double yEl;
            double a = Double.parseDouble(aTF.getText()) + 2;
            double b = Double.parseDouble(bTF.getText()) + 2;
            for (int i=0; i<9; i++) {
                double fact = 1;
                for (int j=0; j<i; j++) { fact += fact * (j+1); }
                yEl = fact - Math.PI*mass[i];
                if (yEl != 0 && (Math.pow(a*a+b*b, 3) * Math.pow(Math.cos(mass[i]), 2) / yEl) >= 0) {
                    yEl = Math.pow(Math.pow(a*a+b*b, 3) * Math.pow(Math.cos(mass[i]), 2) / yEl, 1./3);
                    fillingEl.add(new outputInTab(mass[i], String.valueOf(yEl)));
                } else fillingEl.add(new outputInTab(mass[i], "ОШИБКА"));
                kColumn.setCellValueFactory(new PropertyValueFactory<>("col1"));
                yColumn.setCellValueFactory(new PropertyValueFactory<>("col2")); }
            tablev.setItems(fillingEl);
        }
    }
}