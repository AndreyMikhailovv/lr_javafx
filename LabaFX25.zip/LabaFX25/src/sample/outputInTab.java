package sample;
public class outputInTab {
    private double kColumn;
    private String yColumn;

    public outputInTab(double kColumn, String yColumn) {
        this.kColumn = kColumn;
        this.yColumn = yColumn;
    }

    public outputInTab() {
    }

    public double getCol1() {
        return kColumn;
    }
    public void setCol1(double kColumn) {
        this.kColumn = kColumn;
    }

    public String getCol2() {
        return yColumn;
    }
    public void setCol2(String yColumn) {
        this.yColumn = yColumn;
    }
}