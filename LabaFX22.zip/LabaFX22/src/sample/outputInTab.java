package sample;

public class outputInTab {
    private int col1;
    private int col2;
    private int col3;
    private int col4;
    private int col5;

    public outputInTab(int col1, int col2, int col3, int col4, int col5) {
        this.col1 = col1;
        this.col2 = col2;
        this.col3 = col3;
        this.col4 = col4;
        this.col5 = col5;
    }

    public outputInTab() {
    }

    public int getCol1() {
        return col1;
    }
    public void setCol1(int col1) {
        this.col1 = col1;
    }

    public int getCol2() {
        return col2;
    }
    public void setCol2(int col2) {
        this.col2 = col2;
    }

    public int getCol3() {
        return col3;
    }
    public void setCol3(int col3) {
        this.col3 = col3;
    }

    public int getCol4() {
        return col4;
    }
    public void setCol4(int col4) {
        this.col4 = col4;
    }

    public int getCol5() {
        return col5;
    }
    public void setCol5(int col5) {
        this.col5 = col5;
    }
}
