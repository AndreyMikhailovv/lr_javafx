package sample;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import java.util.Random;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TableView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.cell.PropertyValueFactory;


public class Controller {
    private ObservableList<outputInTab> fillingEl = FXCollections.observableArrayList();
    int[][] mass = new int[5][5];

    @FXML
    private Label maxElLab;

    @FXML
    private Label minElLab;

    @FXML
    private TableView<outputInTab> tablev;

    @FXML
    private TableColumn<outputInTab, Integer> col1;

    @FXML
    private TableColumn<outputInTab, Integer> col2;

    @FXML
    private TableColumn<outputInTab, Integer> col3;

    @FXML
    private TableColumn<outputInTab, Integer> col4;

    @FXML
    private TableColumn<outputInTab, Integer> col5;

    @FXML
    void onClick_RandNumb(ActionEvent event) {
        tablev.getItems().clear();
        Random rnd = new Random();
        for (int i=0; i<5; i++) {
            for (int j=0; j<5; j++) {
                if (rnd.nextInt(4) == 3) mass[i][j] = 0;  //повышение шанса выпадения 0
                else mass[i][j] = rnd.nextInt(41)-20;
            }
            fillingEl.add(new outputInTab(mass[i][0], mass[i][1], mass[i][2], mass[i][3], mass[i][4]));
            col1.setCellValueFactory(new PropertyValueFactory<>("col1"));
            col2.setCellValueFactory(new PropertyValueFactory<>("col2"));
            col3.setCellValueFactory(new PropertyValueFactory<>("col3"));
            col4.setCellValueFactory(new PropertyValueFactory<>("col4"));
            col5.setCellValueFactory(new PropertyValueFactory<>("col5"));
        }
        tablev.setItems(fillingEl);
    }

    @FXML
    void onClick_Run(ActionEvent event) {
        int maxEl = mass[0][0], minEl = mass[0][0];
        for (int i=0; i<5; i++) {
            for (int j=0; j<5; j++) {
                if (maxEl < mass[i][j]) maxEl = mass[i][j];
                if (minEl > mass[i][j]) minEl = mass[i][j];
            }
        }
        if (maxEl > minEl*10) {
            tablev.getItems().clear();
            for (int i=0; i<5; i++) {
                for (int j=0; j<5; j++) {
                    if (mass[i][j] == 0) mass[i][j] = 1;
                    if (mass[i][j] < 0) mass[i][j] = Math.abs(mass[i][j]);
                }
                fillingEl.add(new outputInTab(mass[i][0], mass[i][1], mass[i][2], mass[i][3], mass[i][4]));
                col1.setCellValueFactory(new PropertyValueFactory<>("col1"));
                col2.setCellValueFactory(new PropertyValueFactory<>("col2"));
                col3.setCellValueFactory(new PropertyValueFactory<>("col3"));
                col4.setCellValueFactory(new PropertyValueFactory<>("col4"));
                col5.setCellValueFactory(new PropertyValueFactory<>("col5"));
            }
            tablev.setItems(fillingEl);
        }
        maxElLab.setText(String.valueOf(maxEl));
        minElLab.setText(String.valueOf(minEl));
    }

}